#include "main.h"

/* FDCAN handle */
FDCAN_HandleTypeDef hfdcan1;

/* Transmit header and data */
FDCAN_TxHeaderTypeDef TxHeader;
uint8_t TxData[8];

/* Variables to watch in the debugger */
volatile uint8_t tx_count = 0;
volatile uint8_t tx_value = 100;

volatile uint32_t tx_frames_queued = 0;
volatile uint32_t tx_queue_error = 0;
volatile uint32_t tx_status = 0;
volatile uint32_t tx_check_error = 0;

volatile uint32_t tx_last_bus_error = 0;
volatile uint32_t tx_error_counter = 0;
volatile uint32_t tx_bus_off = 0;
volatile uint32_t tx_fifo_free = 0;

/* Function prototypes */
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_FDCAN1_Init(void);
void Error_Handler(void);

int main(void)
{
    HAL_Init();

    SystemClock_Config();

    MX_GPIO_Init();

    MX_FDCAN1_Init();

    if (HAL_FDCAN_Start(&hfdcan1) != HAL_OK)
    {
        Error_Handler();
    }

    /* Standard classic CAN frame: ID 0x123, 8 bytes */
    TxHeader.Identifier = 0x123;
    TxHeader.IdType = FDCAN_STANDARD_ID;
    TxHeader.TxFrameType = FDCAN_DATA_FRAME;
    TxHeader.DataLength = FDCAN_DLC_BYTES_8;
    TxHeader.ErrorStateIndicator = FDCAN_ESI_ACTIVE;
    TxHeader.BitRateSwitch = FDCAN_BRS_OFF;
    TxHeader.FDFormat = FDCAN_CLASSIC_CAN;
    TxHeader.TxEventFifoControl = FDCAN_NO_TX_EVENTS;
    TxHeader.MessageMarker = 0;

    while (1)
    {
        TxData[0] = tx_count;
        TxData[1] = tx_value;
        TxData[2] = 0x22;
        TxData[3] = 0x33;
        TxData[4] = 0x44;
        TxData[5] = 0x55;
        TxData[6] = 0x66;
        TxData[7] = 0x77;

        tx_status = HAL_FDCAN_AddMessageToTxFifoQ(
            &hfdcan1,
            &TxHeader,
            TxData
        );

        if (tx_status == HAL_OK)
        {
            /* Queued does not necessarily mean acknowledged */
            tx_frames_queued++;
            tx_count++;
        }
        else
        {
            tx_queue_error++;
            tx_check_error = HAL_FDCAN_GetError(&hfdcan1);
        }

        /* Capture diagnostic information for the debugger */
        {
            FDCAN_ProtocolStatusTypeDef protocol;
            FDCAN_ErrorCountersTypeDef counters;

            if (HAL_FDCAN_GetProtocolStatus(
                    &hfdcan1, &protocol) == HAL_OK)
            {
                if ((protocol.LastErrorCode !=
                     FDCAN_PROTOCOL_ERROR_NONE) &&
                    (protocol.LastErrorCode !=
                     FDCAN_PROTOCOL_ERROR_NO_CHANGE))
                {
                    tx_last_bus_error = protocol.LastErrorCode;
                }

                tx_bus_off = protocol.BusOff;
            }

            if (HAL_FDCAN_GetErrorCounters(
                    &hfdcan1, &counters) == HAL_OK)
            {
                tx_error_counter = counters.TxErrorCnt;
            }

            tx_fifo_free =
                HAL_FDCAN_GetTxFifoFreeLevel(&hfdcan1);
        }

        HAL_Delay(100);
    }
}

void SystemClock_Config(void)
{
    RCC_OscInitTypeDef RCC_OscInitStruct = {0};
    RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

    /*
     * Boost mode is required for this G491 configuration
     * because the system clock is 170 MHz.
     */
    if (HAL_PWREx_ControlVoltageScaling(
            PWR_REGULATOR_VOLTAGE_SCALE1_BOOST) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_OscInitStruct.OscillatorType =
        RCC_OSCILLATORTYPE_HSI;

    RCC_OscInitStruct.HSIState = RCC_HSI_ON;

    RCC_OscInitStruct.HSICalibrationValue =
        RCC_HSICALIBRATION_DEFAULT;

    RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
    RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
    RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV4;
    RCC_OscInitStruct.PLL.PLLN = 85;
    RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
    RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
    RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;

    if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
    {
        Error_Handler();
    }

    RCC_ClkInitStruct.ClockType =
        RCC_CLOCKTYPE_HCLK |
        RCC_CLOCKTYPE_SYSCLK |
        RCC_CLOCKTYPE_PCLK1 |
        RCC_CLOCKTYPE_PCLK2;

    RCC_ClkInitStruct.SYSCLKSource =
        RCC_SYSCLKSOURCE_PLLCLK;

    RCC_ClkInitStruct.AHBCLKDivider =
        RCC_SYSCLK_DIV1;

    RCC_ClkInitStruct.APB1CLKDivider =
        RCC_HCLK_DIV1;

    RCC_ClkInitStruct.APB2CLKDivider =
        RCC_HCLK_DIV1;

    if (HAL_RCC_ClockConfig(
            &RCC_ClkInitStruct,
            FLASH_LATENCY_4) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_FDCAN1_Init(void)
{
    hfdcan1.Instance = FDCAN1;

    hfdcan1.Init.ClockDivider = FDCAN_CLOCK_DIV1;
    hfdcan1.Init.FrameFormat = FDCAN_FRAME_CLASSIC;
    hfdcan1.Init.Mode = FDCAN_MODE_NORMAL;

    hfdcan1.Init.AutoRetransmission = ENABLE;
    hfdcan1.Init.TransmitPause = DISABLE;
    hfdcan1.Init.ProtocolException = DISABLE;

    /*
     * 170 MHz / (34 * (1 + 15 + 4))
     * = 250 kbit/s
     */
    hfdcan1.Init.NominalPrescaler = 34;
    hfdcan1.Init.NominalSyncJumpWidth = 1;
    hfdcan1.Init.NominalTimeSeg1 = 15;
    hfdcan1.Init.NominalTimeSeg2 = 4;

    /* Data-phase settings are unused for classic CAN */
    hfdcan1.Init.DataPrescaler = 1;
    hfdcan1.Init.DataSyncJumpWidth = 1;
    hfdcan1.Init.DataTimeSeg1 = 1;
    hfdcan1.Init.DataTimeSeg2 = 1;

    hfdcan1.Init.StdFiltersNbr = 1;
    hfdcan1.Init.ExtFiltersNbr = 0;

    hfdcan1.Init.TxFifoQueueMode =
        FDCAN_TX_FIFO_OPERATION;

    if (HAL_FDCAN_Init(&hfdcan1) != HAL_OK)
    {
        Error_Handler();
    }
}

static void MX_GPIO_Init(void)
{
    __HAL_RCC_GPIOA_CLK_ENABLE();
}

void Error_Handler(void)
{
    __disable_irq();

    while (1)
    {
    }
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
    (void)file;
    (void)line;
}
#endif
